import React from 'react';
import Navbar from '../components/Navbar';
import Footer from '../components/Footer';
function Howtouse(){
    return(
        <div className='bg-sky-500'>
        <Navbar />
        <div>
            
        </div>
        <Footer/>
        </div>
    );

}
export default Howtouse;