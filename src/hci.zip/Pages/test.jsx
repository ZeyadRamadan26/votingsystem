import Footer from "../components/Footer";
function test(){

    return(
        <>
        <Footer/>
        </>
    );

}
export default test;