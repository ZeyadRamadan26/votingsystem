import { useEffect } from "react";

function maps(){
    return(
        <>
            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3412.0500483808264!2d29.936611676857176!3d31.219342774353123!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x14f5c48d872832a3%3A0x8c49af1aec355d90!2s8%20Al%20Dar%20Al%20Baidaa%2C%20Sidi%20Gabir%2C%20Sidi%20Gaber%2C%20Alexandria%20Governorate%205433044!5e0!3m2!1sen!2seg!4v1715009112472!5m2!1sen!2seg" style={{width:'50%', height:'450px',marginLeft:'20px'}}></iframe>
     
        </>
    );
}
// useEffect() => {

// }
export default maps;